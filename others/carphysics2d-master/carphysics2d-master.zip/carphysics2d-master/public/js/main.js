/*global App */

"use strict";

//  Boot up the app
window.addEventListener('load', function(){App.run();}, false);
