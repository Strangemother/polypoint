"use strict";

/**
 *  DOM Utils
 */

/**  Shorthand for document.getElementById */
function $e( id )
{
	return document.getElementById(id);
}
